import { Injectable } from '@angular/core';
import { CONFIG } from '../../shared/config';
import { HttpGeneralService, OutpatientParms } from '../../shared';
import { PatientReservation } from './portal-new-reservation-interface';

const reservationVisitUrl = CONFIG.baseUrls.reservationVisit;

@Injectable({
  providedIn: 'root'
})
export class PortalNewReservationService {
  constructor(private _httpGeneralService: HttpGeneralService) { }

  getSpecialityServices(outpatientParms: OutpatientParms) {
    return this._httpGeneralService.add(outpatientParms, `${reservationVisitUrl}/SpecialityService`);
  }

  getSpecialityDoctors(data: IReservationFastSerachObj) {
    return this._httpGeneralService.post(data, `${reservationVisitUrl}/GetAvailableDoctorsBySpeciality`);
  }

  getDoctors(specialId: number) {
    return this._httpGeneralService.getWith(`${reservationVisitUrl}/Doctors/${specialId}`);
  }

  addPatientReservation(PatientReservation: PatientReservation) {
    return this._httpGeneralService.add(PatientReservation, `${reservationVisitUrl}`);
  }
  addBookCheckUp(regPatVisitVM: any) {
    return this._httpGeneralService.post(regPatVisitVM, `${reservationVisitUrl}/AddBookCheckUp`);
  }

} 



export interface IReservationFastSerachObj {
  specialityId?: number;
  reservationDate?: Date;
  resourceType?: number;
  entityType?: number;
  docCode?: number;
}


export interface IDoctorsCards {
  code: number;
  doctorNameAr: string;
  doctorNameEn: string;
  mobile: string;
  addressAr: string;
  addressEn: string;
  gender: number;
  genderAr: string;
  genderEn: string;
  nameAr: string;
  nameEn: string;
  docCatNameAr: string;
  docCatNameEn: string;
  specialtyNameAr: string;
  specialtyNameEn: string;
  dayAr: string;
  dayEn: string;
  weekDayCode: number;
  timesAvailable: IAvailableTimes[],
  timeNotAvailableMsg: string;
  shortTimes: IAvailableTimes[];
  _date: string;
  reservationDate: any;
  mobileOnPortal: any;
  timeFound: boolean;
}
export interface IAvailableTimes {
  startTime: string;
  resourceId: number;
  startTimeSlot: string;
  endTimeSlot: string;
  servStatus: any;
  scheduleTimeSerial: number;
  id: number;
}